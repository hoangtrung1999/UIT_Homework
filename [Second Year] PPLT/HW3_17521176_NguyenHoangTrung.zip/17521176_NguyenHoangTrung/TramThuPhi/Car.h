#include <iostream>
#include <queue>
using namespace std;

struct Xe
{
	string BienSo;
	string LoaiXe;
	double ThoiGianThuPhi;
};

