#include <iostream>
#include <string>
#include <queue>
#include <ctime>
#include "Car.h"
using namespace std;

void NhapDuLieu(int n);
void XuatThongTin(int n);
