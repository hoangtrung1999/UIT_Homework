#include "Utility.h"

using namespace std;

queue <Xe> HangXe;

void NhapDuLieu(int n)
{
	for (int i = 0; i < n; i++)
	{
		Xe xe;
		cout << "----------------------------------" << endl;
		cout << "Thong tin xe thu " << i + 1 << endl;

		int bienso;
		bienso = rand() % 9999 + 1000;
		xe.BienSo = std::to_string(bienso);
		cout << "Bien So: "<<xe.BienSo<<endl;

		int loaixe;
		loaixe = rand() % 3;
		switch (loaixe)
		{
		case 0:
			xe.LoaiXe = "Xe Oto";
			break;
		case 1:
			xe.LoaiXe = "Xe May";
			break;
		case 2:
			xe.LoaiXe = "Xe Tai";
			break;
		case 3:
			xe.LoaiXe = "Xe Khach";
			break;
		}

		cout << "Loai Xe: " << xe.LoaiXe<<endl;

		int thoigianthuphi;
		thoigianthuphi = rand() % 10 + 1;
		xe.ThoiGianThuPhi = thoigianthuphi;
		cout << "Thoi gian thu phi: "<<xe.ThoiGianThuPhi<<endl;
		//cin.ignore();
		HangXe.push(xe);
	}
}

void XuatThongTin(int n)
{
	cout << "-------------------------------------" << endl;
	time_t begin;
	time_t finish;
	for (int i = 0; i < n; i++)
	{
		cout << "************Dang thu phi*************" << endl;
		Xe xe = HangXe.front();
		HangXe.pop();

		time(&begin);
		time(&finish);
		do
		{
			time(&finish);
		} while (difftime(finish, begin) < xe.ThoiGianThuPhi);

		cout << "Thong tin xe thu " << i + 1 << endl;
		cout << "Bien So: " << xe.BienSo << endl;
		cout << "Loai Xe: " << xe.LoaiXe << endl;
		cout << "Thoi gian thu phi: " << xe.ThoiGianThuPhi << endl;
		cout << "-------------------------------------" << endl;
	}

}