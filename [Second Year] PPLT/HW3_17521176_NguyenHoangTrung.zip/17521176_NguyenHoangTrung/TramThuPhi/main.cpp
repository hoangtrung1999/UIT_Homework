#include "Utility.h"
#include <ctime>
using namespace std;

int main()
{
	int n;
	srand(time(NULL));
	n = rand() % 10 + 2;

	cout << "So luong xe: "<<n<<endl;
	//cin.ignore();
	NhapDuLieu(n);
	XuatThongTin(n);

	return 0;
}