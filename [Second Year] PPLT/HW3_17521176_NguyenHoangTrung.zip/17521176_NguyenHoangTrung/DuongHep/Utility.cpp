#include "Utility.h"

Xe NhapThongTinXe()
{
	Xe xe;

	int bienso;
	bienso = rand() % 9999 + 1000;
	xe.BienSo = std::to_string(bienso);
	cout << "Bien So: " << xe.BienSo << endl;

	int loaixe;
	loaixe = rand() % 3;
	switch (loaixe)
	{
	case 0:
		xe.LoaiXe = "Xe Oto";
		break;
	case 1:
		xe.LoaiXe = "Xe May";
		break;
	case 2:
		xe.LoaiXe = "Xe Tai";
		break;
	case 3:
		xe.LoaiXe = "Xe Khach";
		break;
	}

	cout << "Loai Xe: " << xe.LoaiXe << endl;
	
	return xe;
}

void XepHangXe(queue<Xe> &HangXe)
{
	int size;
	size = rand() % 10 + 1;
	for (int i = 0; i < size; i++)
	{
		Xe xe;
		cout << "Xe thu " << i + 1 << endl;
		xe = NhapThongTinXe();
		HangXe.push(xe);
	}
}

void ChoXeChay(queue<Xe>& HangXe1st, queue<Xe>& HangXe2nd, stack<Xe>& HangXeDoi)
{
	do
	{
		Xe xe;
		xe = HangXe2nd.front();
		HangXeDoi.push(xe);
		HangXe2nd.pop();
	} while (!HangXe2nd.empty());

	cout << "Cho hang xe co nhieu xe hon di chuyen truoc!" << endl;

	int i = 0;
	do
	{
		cout << "-------------------------------" << endl;
		cout << "Thong tin xe dang di chuyen!" << endl;
		Xe xe;
		xe = HangXe1st.front();

		cout << "Thong tin xe thu " << i + 1 << endl;
		cout << "Bien So: " << xe.BienSo << endl;
		cout << "Loai Xe: " << xe.LoaiXe << endl;
		i++;
		HangXe1st.pop();
	} while (!HangXe1st.empty());

	do
	{
		cout << "-------------------------------" << endl;
		cout << "Thong tin xe dang di chuyen!" << endl;
		Xe xe;
		xe = HangXeDoi.top();

		cout << "Thong tin xe thu " << i + 1 << endl;
		cout << "Bien So: " << xe.BienSo << endl;
		cout << "Loai Xe: " << xe.LoaiXe << endl;
		i++;
		HangXeDoi.pop();
	} while (!HangXeDoi.empty());
}
