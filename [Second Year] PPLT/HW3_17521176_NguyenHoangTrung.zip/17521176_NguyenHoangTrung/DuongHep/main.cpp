#include "Utility.h"
#include <iostream>
#include <ctime>

using namespace std;

int main()
{
	srand(time(NULL));

	queue <Xe> HangXePhai;
	queue <Xe> HangXeTrai;
	stack <Xe> HangXeDoi;

	cout << "Thong tin hang xe phai" << endl;
	XepHangXe(HangXePhai);
	cout << "---------------------------" << endl;
	cout << "Thong tin hang xe trai" << endl;
	XepHangXe(HangXeTrai);
	cout << "-----------------------------" << endl;
	if (HangXePhai.size() > HangXeTrai.size())
	{
		cout << "Hang xe phai co nhieu xe hon!" << endl;
		ChoXeChay(HangXePhai, HangXeTrai, HangXeDoi);
	}
		
	else
	{
		cout << "Hang xe trai co nhieu xe hon!" << endl;
		ChoXeChay(HangXeTrai, HangXePhai, HangXeDoi);
	}
	getchar();
	return 0;
}
