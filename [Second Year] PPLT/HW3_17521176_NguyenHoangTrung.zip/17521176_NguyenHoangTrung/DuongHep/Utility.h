#include <iostream>
#include "Car.h"
#include <queue>
#include <stack>
using namespace std;

//queue <Xe> HangXePhai;
//queue <Xe> HangXeTrai;

Xe NhapThongTinXe();
void XepHangXe(queue<Xe> &HangXe);
void ChoXeChay(queue<Xe> &HangXe1st, queue<Xe> &HangXe2nd, stack<Xe> &HangXeDoi);