#include "Car.h"
#include "Boat.h"

void NhapThongTinPha(Pha &pha);
void DuaXeLenPha(Pha &pha, int &TongTaiTrong, int n, queue<Xe> &HangXe);