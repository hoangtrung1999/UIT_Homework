#ifndef CAR_H
#define CAR_H
#include <iostream>
#include <string>
#include <queue>
using namespace std;

struct Xe
{
	string BienSo;
	string LoaiXe;
	int TaiTrong;
};
void NhapThongTinXe(int n, queue<Xe> &HangXe);
#endif