#include "Utility.h"
#include <iostream>
#include <ctime>
using namespace std;

int main()
{
	int n;
	srand(time(NULL));
	n = rand() % 10 + 1;
	cout << "So luong xe: ";

	queue <Xe> HangXe;
	NhapThongTinXe(n, HangXe);

	Pha pha;
	int TongTaiTrong = 0;

	NhapThongTinPha(pha);


	DuaXeLenPha(pha, TongTaiTrong, n, HangXe);
	getchar();
	return 0;
}