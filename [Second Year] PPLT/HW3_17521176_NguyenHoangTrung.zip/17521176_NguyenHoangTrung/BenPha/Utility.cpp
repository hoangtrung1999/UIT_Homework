#include "Utility.h"

void NhapThongTinPha(Pha &pha)
{
	int SucChua;
	SucChua = rand() % 200 + 500;
	pha.SucChua = SucChua;
	cout << "Suc chua cua pha: " << pha.SucChua << endl;
}

void DuaXeLenPha(Pha &pha, int &TongTaiTrong, int n, queue<Xe> &HangXe)
{
	for (int i = 0; i < n; i++)
	{
		Xe xe = HangXe.front();
		HangXe.pop();
		TongTaiTrong += xe.TaiTrong;
		if (TongTaiTrong <= pha.SucChua)
		{
			cout << "***Cho phep xe len pha***" << endl;
			cout << "Thong tin xe thu " << i + 1 << endl;
			//cout << "Bien So: " << xe.BienSo << endl;
			//cout << "Loai Xe: " << xe.LoaiXe << endl;
			cout << "Tai Trong: " << xe.TaiTrong << endl;
		}
		else
		{
			cout << "***Pha khong the chua them xe***" << endl;
			break;
		}
	}
}