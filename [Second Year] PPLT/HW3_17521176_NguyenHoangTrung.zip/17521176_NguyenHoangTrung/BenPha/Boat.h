#ifndef BOAT_H
#define BOAT_H
#include <iostream>

struct Pha
{
	int SucChua;
};
#endif
