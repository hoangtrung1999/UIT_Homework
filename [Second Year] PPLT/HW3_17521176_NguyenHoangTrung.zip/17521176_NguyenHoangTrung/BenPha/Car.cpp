#include "Car.h"
using namespace std;

void NhapThongTinXe(int n, queue<Xe> &HangXe)
{
	for (int i = 0; i < n; i++)
	{
		Xe xe;
		cout << "--------------------------------" << endl;
		cout << "Thong tin xe thu " << i + 1 << endl;

		int bienso;
		bienso = rand() % 9999 + 1000;
		xe.BienSo = std::to_string(bienso);
		cout << "Bien So: "<<xe.BienSo<<endl;
		
		int loaixe;
		loaixe = rand() % 3;
		switch (loaixe)
		{
		case 0:
			xe.LoaiXe = "Xe oto";
			break;
		case 1:
			xe.LoaiXe = "Xe May";
			break;
		case 2:
			xe.LoaiXe = "Xe Dap";
			break;
		case 3:
			xe.LoaiXe = "Xe Moto";
			break;
		}
		cout << "Loai Xe: " << xe.LoaiXe << endl;

		int TaiTrong;
		TaiTrong = rand() % 100 + 100;
		xe.TaiTrong = TaiTrong;
		cout << "Tai trong xe: " << xe.TaiTrong << endl;
		HangXe.push(xe);
	}
}
