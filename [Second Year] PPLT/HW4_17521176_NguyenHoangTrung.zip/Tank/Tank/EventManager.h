#pragma once
#include "Tank.h"

void Shooting(Tank& A, Tank& B);

