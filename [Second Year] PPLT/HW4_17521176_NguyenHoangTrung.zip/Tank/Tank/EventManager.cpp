#include "EventManager.h"

void Shooting(Tank& A, Tank& B)
{
	string A_Name = A.GetName();
	string B_Name = B.GetName();
	cout << A_Name << " ban " << B_Name;
	cout << "Kich thuoc phao cua " << A_Name << ": " << A.GetPhao() << endl;
	cout << "Do day giap cua " << B_Name << ": " << B.GetGiap() << endl;
	cout << A_Name << " >==========>" << B_Name << endl;
	B.TruGiap(A.GetPhao());
	cout << "Giap " << B_Name << " con lai: " << B.GetGiap() << endl;
}
