#include <iostream>
#include "EventManager.h"
#include "Tank.h"

using namespace std;
Tank ChooseTank(char name, Tank1 &A, Tank2 &B, Tank3 &C, Tank4 &D);
int main()
{
	Tank1 A(300, 85, 7.62);
	Tank2 B(400, 85, 7.62, 82);
	Tank3 C(500, 100, 6.72, 12.7);
	Tank4 D(700, 120, 7.62);

	InThongTinXe(&A);
	InThongTinXe(&B);
	InThongTinXe(&C);
	InThongTinXe(&D);
	
	char name_shooter;
	char name_target;
	char decision;
	Tank target;
	Tank shooter;
	do
	{
		cout << "Nhap ten xe muon ban: ";
		cin >> name_shooter;
		cin.sync();
		shooter = ChooseTank(name_shooter, A, B, C, D);
		cout << "Nhap ten xe thuc hien ban: ";
		cin >> name_target;
		cin.sync();
		target = ChooseTank(name_target, A, B, C, D);
		getchar();

		Shooting(shooter, target);
		cout << "Ban tiep? (Y/N): ";
		cin >> decision;
	} while (decision != 'N');

	getchar();
	return 0;
}

Tank ChooseTank(char name, Tank1 &A, Tank2 &B, Tank3 &C, Tank4 &D)
{
	Tank target;
	switch (name)
	{
	case 'A':
		target = A;
		break;
	case 'B':
		target = B;
		break;
	case 'C':
		target = C;
		break;
	case 'D':
		target = D;
		break;
	}
	return target;
}
