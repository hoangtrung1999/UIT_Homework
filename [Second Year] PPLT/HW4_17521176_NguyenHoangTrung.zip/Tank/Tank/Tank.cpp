#include "Tank.h"

#pragma region Tank
Tank::Tank()
{
}


Tank::Tank(int Giap, int KichThuocKichThuocPhao, double SungMay) : Giap(0), KichThuocPhao(0), SungMay(0)
{
}

void Tank::InThongTin()
{
	cout << "Tank" << endl;
	cout << "Giap: " << this->Giap << endl;
	cout << "KichThuocPhao: " << this->KichThuocPhao << endl;
	cout << "Sung May: " << this->SungMay << endl;
}

Tank::~Tank()
{
}
#pragma endregion
#pragma region Tank1
Tank1::Tank1(int Giap, int KichThuocPhao, double SungMay)
{
	this->Name = "Tank A";
	this->Giap = Giap;
	this->KichThuocPhao = KichThuocPhao;
	this->SungMay = SungMay;
}

void Tank1::InThongTin()
{
	cout << Name << endl;
	cout << "Giap: " << this->Giap << endl;
	cout << "KichThuocPhao: " << this->KichThuocPhao << endl;
	cout << "Sung May: " << this->SungMay << endl;
}

Tank1::Tank1()
{

}

Tank1::~Tank1()
{
}

#pragma endregion
#pragma region Tank2
Tank2::Tank2(int Giap, int KichThuocPhao, double SungMay, int Coi)
{
	this->Giap = Giap;
	this->KichThuocPhao = KichThuocPhao;
	this->SungMay = SungMay;
	this->Coi = Coi;
	this->Name = "Tank B";
}

void Tank2::InThongTin()
{
	cout << Name << endl;
	cout << "Giap: " << this->Giap << endl;
	cout << "KichThuocPhao: " << this->KichThuocPhao << endl;
	cout << "Sung May: " << this->SungMay << endl;
	cout << "Coi: " << this->Coi << endl;
}

Tank2::Tank2()
{

}

Tank2::~Tank2()
{
}

#pragma endregion
#pragma region Tank3
Tank3::Tank3(int Giap, int KichThuocPhao, double SungMay, double SungMayPhu)
{
	this->Giap = Giap;
	this->KichThuocPhao = KichThuocPhao;
	this->SungMay = SungMay;
	this->SungMayPhu = SungMayPhu;
	this->Name = "Tank C";
}
void Tank3::InThongTin()
{
	cout << Name << endl;
	cout << "Giap: " << this->Giap << endl;
	cout << "KichThuocPhao: " << this->KichThuocPhao << endl;
	cout << "Sung May: " << this->SungMay << endl;
	cout << "Sung May Phu: " << this->SungMayPhu << endl;
}
Tank3::Tank3()
{

}
Tank3::~Tank3()
{
}

#pragma endregion
#pragma region Tank4
Tank4::Tank4()
{
}

Tank4::~Tank4()
{
}

Tank4::Tank4(int Giap, int KichThuocPhao, double SungMay)
{
	this->Giap = Giap;
	this->SungMay = SungMay;
	this->TTPhao->KichThuoc = KichThuocPhao;
	this->LoaiDan = LoaiDan;
	this->Name = "Tank D";
	cout << "Nhap loai dan cho Tank 4 (1,2,3,4): ";
	cin >> this->LoaiDan;
	this->KichThuocPhao = this->TTPhao->KichThuoc * this->LoaiDan;
	getchar();
}

void Tank4::InThongTin()
{
	cout << Name << endl;
	cout << "Giap: " << this->Giap << endl;
	cout << "Kich Thuoc Phao: " << this->TTPhao->KichThuoc << endl;
	cout << "Sung May: " << this->SungMay << endl;
	switch (LoaiDan)
	{
	case 1:
		cout << "Dan Pha Manh" << endl;
		break;
	case 2:
		cout << "Dan No" << endl;
		break;
	case 3:
		cout << "Dan Xuyen Giap" << endl;
		break;
	case 4:
		cout << "Dan Ten Lua" << endl;
		break;
	}
}
#pragma endregion

void InThongTinXe (Tank *tank)
{
	tank->InThongTin();
}