#pragma once
#ifndef TANK_H
#define TANK_H
#include <iostream>
#include <string>
using namespace std;
class Tank
{
protected:
	int Giap;
	int KichThuocPhao;
	double SungMay;
	string Name;
public:
	Tank();
	Tank(int Giap, int KichThuocPhao, double SungMay);
	virtual void InThongTin();
	inline string GetName()
	{
		return Name;
	}
	inline int GetGiap()
	{
		return Giap;
	}
	inline int GetPhao()
	{
		return KichThuocPhao;
	}
	inline void TruGiap(int x)
	{
		Giap -= x;
	}
	~Tank();
};

class Tank1 : public Tank
{
public:
	Tank1();
	Tank1(int Giap, int KichThuocPhao, double SungMay);
	inline void InThongTin();
	~Tank1();
};

class Tank2 : public Tank
{
protected:
	int Coi;
public:
	Tank2();
	Tank2(int Giap, int KichThuocPhao, double SungMay, int Coi);
	inline void InThongTin();
	~Tank2();
};

class Tank3 : public Tank
{
private:
	double SungMayPhu;
public:
	Tank3();
	Tank3(int Giap, int KichThuocPhao, double SungMay, double SungMayPhu);
	inline void InThongTin();
	~Tank3();
};

class Tank4 : public Tank3
{
protected:
	struct ThongTinPhao
	{
		int KichThuoc;
		double PhaManh;
		double No;
		double XuyenGiap;
	};
	ThongTinPhao* TTPhao = new ThongTinPhao;
	int LoaiDan;
public:
	Tank4();
	~Tank4();
	Tank4(int Giap, int KichThuocPhao, double SungMay);
	inline void InThongTin();
};

void InThongTinXe(Tank *tank);
#endif // !TANK_H

